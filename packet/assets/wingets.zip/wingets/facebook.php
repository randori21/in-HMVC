<div class="sidemenu" style="margin-top: 10px;">
                            <h3 >Suka </h3>
                            <div class="fb-like" data-href="http://stmikka.ac.id/" data-send="true" data-width="280" data-show-faces="true" data-font="arial" style="margin: 0 10px 0 10px;"></div>
                            </div>