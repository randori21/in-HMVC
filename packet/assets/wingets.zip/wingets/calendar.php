                            <div class="sidemenu" style="margin-top: 10px; ">
                            <h3>Kalender Kegiatan</h3>
                            <iframe src="https://www.google.com/calendar/embed?showTitle=0&amp;showTabs=0&amp;height=300&amp;wkst=2&amp;bgcolor=%23FFFFFF&amp;src=stmik2011%40gmail.com&amp;color=%23875509&amp;src=in.indonesian%23holiday%40group.v.calendar.google.com&amp;color=%232952A3&amp;ctz=Asia%2FJakarta" style=" border-width:0 " width="298" height="300" frameborder="0" scrolling="no"></iframe>
                            </div>